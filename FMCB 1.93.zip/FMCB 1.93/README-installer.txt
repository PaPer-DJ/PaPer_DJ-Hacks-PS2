Free Memory Card Boot (FMCB) installer v0.95 - 2013/13/10
---------------------------------------------------------

I've spent slightly over a hundred hours working on this, and I hope that it works well.... but of course, anything could go wrong - so I have provided a memory card dumping and restoration facility within the installer.

A dump of a memory card in slot 1 will get saved as mc0.bin, and a dump of a card in slot 1 will get saved as mc1.bin.
The file will be saved to the directory where the main executable of this installer resides in.

Caution! You can only make one dump of a card from each port. Making additional dumps will overwrite the previous dump.

During development, I have sent 2 of my cards to their graves and damaged their filesystems. Thank goodness for the dumps that I made at the beginning of this project!
(I seriously don't know what's wrong with those damaged cards... they were hardly used and now they won't be detected at all).

All consoles should be supported, and no additional files should be required.
I've tested the installer on my SCPH-10000 console, and it works fine too.

!!! WARNING !!! If you make a multi-install, DO NOT DELETE ANY OF THE B*EXEC-SYSTEM FOLDERS OR ANY OF THE OSD*.elf FILES INSIDE THEM!
Doing so might result in _SEVERE_ data loss.
Do not delete uninstall.dat from the SYS-CONF folder either, or you will probably be stuck with the multi-install files forever (Unless you use the cleanup utility, but it has it's own limitations).

Lastly, please do give feedback. Other than the bugs listed below, I do hope that this release has met the requirements of the public.

How to setup this software:
---------------------------
Extract the main binary (FMCBInstaller.elf) and the lang folder (do not delete any files, especially the DejaVu font!), and place both of them in the same place. The only supported devices are the Memory Card, CD/DVD drive and USB mass storage device.

What's the difference between a multi-install and a normal cross-region installation?
-------------------------------------------------------------------------------------
A long time ago when FMCB v1.8b was just released, only the multi-installation mode existed. It allowed users to make an installation of FMCB that worked on all consoles within the same region by introducing crosslinking (controlled corruption) into the memory card's filesystem. That was to save space, because it used to create about 20 crosslinked files due to the developers not knowing which exact boot ROMs will look for version-specific update files.

The older PlayStation 2 consoles were coded to boot an update for only its ROM version, meaning that a console with v1.20 will only boot osd130.elf. Newer consoles will look for a different file. This practice was scrapped by Sony later on (at boot ROM v1.60), but such older consoles still exist on this planet.

The multi-installation of v1.8C now allows cross-regional installations to be done, but still uses controlled filesystem corruption.

However, with the discovery of exactly which boot ROMs will look for version-specific update files, it has been found that only a handful of models actually have this need. The number of times the FMCB binary needs to be copied has been reduced to 5. With the small binary size of v1.8c, the amount of space required for a cross-regional installation without crosslinking has been greatly reduced.

Basically, a normal cross-regional installation does exactly the same thing as a multi-installation, but duplicates the FMCB binary instead of crosslinking entries. It's safer and does not go against the limitations (and design) of the memory card filesystem.


Notes regarding the sources:
----------------------------
Within the sources, I have created:
1. SECRMAN, a clone of the Sony Security Manager (SECRMAN) module that has card-binding functions (SecrDownload*).
2. SECRSIF, a clone of the Sony Security Manager SIF RPC server.
3. MCTOOLS, a RPC server module that provided misceallenous functions for the memory cards like dumping and restoration, and filesystem manipulation.
4. UDNL, the Updater module. Used for updating the IOP with newer modules (Which is only SECRMAN for this installer).

Hopefully, they will be useful for the homebrew community after their release.

About building the updater module (must be done if SECRMAN is modified):
1. A tool that can generate ROM images (IOPRP file) is required. If you need one, use ROMIMG: http://ichiba.geocities.jp/ysai187/PS2/ROMIMG
2. The image should be named IOPRP.IMG and placed in UDNL/src, before UDNL is rebuilt.

Known bugs and limitations:
---------------------------
-None

Supported installation media:
-----------------------------
*USB devices
*The CD/DVD drive (Assuming that your console has a modchip or you are using a program like ESR)
*Memory card.

Credits:
--------
Jimmikaelkael and Neme, as they were the original developers of FMCB.
Silverbull, for help with UDNL's construction (and with various issues related to the kernels).
Jimmikaelkael (Yes, again), as his MCMAN and MCSP modules, and the MCID file of FMCB v1.7 were used as referrences. FMCB v1.8C was also released by him.
Ross Ridge, as his page on the PS2 Memory Card filesystem was invaluable: http://www.csclub.uwaterloo.ca:11068/mymc/ps2mcfs.html
"Someone who wishes to remain anonymous"
JNABK, since I'm still using the icons he provided me with for use in PS2ESDL.
l_Oliveria for contributing information related to the special needs (required kernel patches) of the SCPH-10000 and SCPH-15000, as well as information related to the boot ROM updates.
...And to all contributers and beta testers!

Anyone else missed here was not intentional.