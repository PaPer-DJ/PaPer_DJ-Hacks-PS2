#############################################################################
#############################################################################
#									    #
#	  		    HDL DUMP HELPER GUI v2.1			    #
#									    #
#############################################################################
#############################################################################
# HDL DUMP HELPER GUI ist ein grafisches, in Java geschriebenes Programm,   #
# welches den Umgang mit dem Kommandozeilen-Programm hdl_dump auf           #
# grafischer Ebene ergänzt und somit einfacher macht.			    #
#			     Geschrieben: 05/07			  	    #
#				Simon Schaal				    #
#############################################################################


Willkommen im Readme zu HDL DUMP HELPER GUI!

HDL DUMP HELPER GUI bietet so gut wie alle Funktionen von hdl_dump, die 
im folg. Text grob aufgelistet werden:

- Installieren von PS2 Spielen auf die sich in der PS2 befindenden Festplatte 
  per Netzwerk oder auf eine lokal verbundene für hdl_dump formatierte Festplatte 
  (auch USB), wobei die Eingabe über grafische Bedienelemente geschieht,
  auch eine Job-Liste ist dabei. 
- Anzeigen der auf der PS2 Festplatte befindlichen Spiele in einer Tabelle
- Löschen der sich auf der PS2 Festplatte befindenden Spiele
- Editieren der sich auf der PS2 Festplatte befindenden Spiele
- Extrahieren von sich auf der PS2 Festplatte befindenden Spiele



Die Benutzung:

Zur Benutzung denke ich muss ich nichts sagen, denn es sollte eigentlich alles 
ziemlich selbsterklärend sein und da Fehler auch durch hilfreiche Fehlermeldungen
genannt werden sollten diese auch, falls es sich um Eingabe Fehler handelt,
leicht behoben werden können.
HDL DUMP HELPER GUI kann mit Windows und Linux Betriebsystemen verwendet werden,
von mir getestet auf WIN XP/Vista und SuSE 10.1/Sidux/Kubuntu.
VORAUSSETZUNG ist eine Installation der aktuellen Java Runtime Environment (JRE),
da dieses Programm in Java geschrieben ist!



Starten von HDL DUMP HELPER GUI:

Windows:
Um das HDL DUMP HELPER GUI unter Windows zu starten muss einfach das Programm 
per Doppelklick auf die hdldh_gui.jar gestartet werden.
Andernfalls habe ich auch noch eine eigentlich nicht notwendige exe Datei 
integriert, für die, die einfach gerne eine exe Datei mit icon wollen.
Also dann die exe Datei starten.
Falls sich das Jar-Archiv und die exe aus irgendeinem Grund nich starten 
lassen kann man es immer noch über die Windows Kommandozeile starten.
Dazu einmal Start->Ausführen-> 'cmd' eingeben (ohne ' ') und mit dem 
'cd' Befehl in das Verzeichnis wecheln, wo sich das HDL DUMP HELPER GUI
befindet. Nun gebt ihr 'java -jar de.hdld.gui.HdlDHGui.jar' ein und es sollte klappen.
Falls nicht würde ich mal darüber nachdenken, ob überhaupt die JRE installiert
ist ;).

Linux:
Unter Linux ist es leider nicht so komfortabel das HDL DUMP HELPER GUI
zu starten. Hier ist es einmal möglich meinen kleinen Bash-Script
Launcher zu nutzen. Dazu müsst ihr einfach eine Konsole öffnen und
in das Verzeichnis wechseln wo sich das HDL DUMP HELPER GUI befindet
und dort './launcher-linux' eingeben zum Ausführen des Launchers oder
den Launcher per Klick starten, je nach dem.
Eine andere Möglichkeit ist noch das Eingeben von 'java -jar de.hdld.gui.HdlDHGui.jar'.
Falls es zu irgendwelchen komisch Fehlern kommt kann es nützlich sein noch 
einmal die Rechte alle Dateien (auch im files Ordner) mit 'chmod 777 *.*'
zu setzen.
Mit Hilfe meines Launchers ist es dann auch möglich eine Desktop Verknüpfung
zu erstellen. Dazu klickt bei SuSE Linux mit rechter Maustaste auf den Desktop
und wählt 'Neu Erstellen' -> 'Verknüpfung zu Programm ...'.
Bei der Registerkarte Allgemein könnt ihr dann den Namen für die Verknüpfung
eingeben. Nun wechselt zu 'Programme'. 
Klickt bei 'Befehl' auf 'Auswählen ...' und sucht dort den 'launcher-linux.sh'. 
Bei 'Arbeitsordner' klickt ihr auf das Ordnersymbol und sucht dort
den Ordner, in dem sich die 'launcher-linux.sh' Datei befindet. 
Optional kann noch ein Icon hinzugefügt werden. Dazu wechselt nochmal
zur Registerkarte 'Allgemein' und klickt auf das Symbol links oben.
Wählt 'Sonstige Symbole' -> 'Auswählen' und sucht die 'desk_icon.png'
in dem mitgelieferten files/ Ordner. Wenn das getan ist könnt ihr dies
alles Abschließen durch drücken der OK Buttons.
Nun habt ihr eine Desktop-Verknüpfung!


Kritik, Verbesserungen:

Falls Euch noch Verbesserungen, Anregungen oder Wünsche einfallen, dann immer mal her damit!
Gefundene Fehler sind natürlich auch Willkommen.
Diese könnt ihr loswerden in dem Thread im modcontrol.com Forum 
oder wegen mir auch per Mail:
http://www.modcontrol.com/Board/thread.php?threadid=6494
nomis-s@gmx.de



Erläuterung der mitgelieferten Dateien:

Im Ordner files/ befinden sich alle vom HDL DUMP HELPER GUI benötigten Dateien, darunter 
auch die Windows- und Linuxversionen von hdl_dump.
Weitere Dateien, die sich in dem files/ Ordner befindet sind die hdld_svr_0.xx.elf Dateien, welche
den HDL DUMP SERVER, welcher auf der PS2 gestartet werden muss darstellt.
Ebenso wird dort die Einstellungsdatei gespeichert, sowie die Sprachdateien und die Hilfe.

Für weitere Informationen/Hilfe schaut euch die help_de.html Datei aus dem files/ Ordner oder 
startet die Hilfe im Programm.

