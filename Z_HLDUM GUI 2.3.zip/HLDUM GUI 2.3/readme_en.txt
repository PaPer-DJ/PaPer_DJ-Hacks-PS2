#############################################################################
#############################################################################
#									    #
#	  		    HDL DUMP HELPER GUI v2			    #
#									    #
#				   Readme				    #
#############################################################################
#############################################################################



HDL Dump Helper GUI is a graphical program, which helps to install PS2 games from a PC onto the PS2. Its based on the command line program hdl_dump and includes mostly all its functions in an easier way. 
With it you can install PS2 games over LAN or on a locally connected PS2 HDD through IDE or USB. It also can list and edit the installed games from the HDD which is stored in your PS2. You also can copy the games back from the PS2 HDD onto your PC. 

HDL Dump Helper GUI is coded in Java and therefore it works on nearly all OS (e.g. many Linux Distributions, Windows) except MAC OS, because there is no hdl_dump for MAC included.  
The only thing you need is the Java Runtime Environment in the latest Version.
The program should be very self explaining because of its tool tips.

To start the GUI on Windows you can use the .exe file or just double click .jar file, which should also work when JRE is successfully installed.
If both things arent working then goto 'Start' -> 'Run' and type 'cmd'. Then switch to the folder containing the GUI using the command 'cd'. 
Now type 'java -jar hdldh_gui.jar' and the GUI should start up.

To start the GUI on a Linux Distribution you can double click the bash-script ./launcher-linux if its made executable via 'chmod +x <file>'.
If you are in the console you can also type ./launcher-linux or 'java -jar hdldh_gui.jar'.
You also can create a desktop shortcut if you want. I included an icon which you can use for it in the '/files' folder called desk_icon.png. Just choose the bash script and the icon when creating a desktop shortcut.

The offical release thread can be found here:
http://www.modcontrol.com/Board/thread.php?threadid=6494

Feel free to contact me with any suggestions.
(nomis-s@gmx.de)

For more help use the help of the program. You also can manually access it by opening the help.html file in the files/ folder with a browser.
