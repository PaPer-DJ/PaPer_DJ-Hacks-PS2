#!/bin/bash
# Launcher für den HDL DUMP HELPER GUI unter Linux
java -jar de.hdld.gui.HdlDHGui.jar 
