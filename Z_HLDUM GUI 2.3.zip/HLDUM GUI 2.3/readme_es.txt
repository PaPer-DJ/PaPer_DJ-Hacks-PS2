#############################################################################

#############################################################################

#									    #

#	  		            HDL DUMP HELPER GUI v2.2		    #
#									    #

#############################################################################

#############################################################################

# HDL DUMP HELPER GUI es una interfaz gr�fica programada en Java,           #

# la cual ayuda al usuario a usar de forma sencilla el programa de l�nea de # 
# instrucciones Hdl_Dump.                                                   #

#			                                                    #

#			     Escrito: 05/07			  	    #

#				 Autor: Simon Schaal                        #

#                Traducci�n: El_Patas				            #

#############################################################################




Con HDL Dump Helper GUI puedes organizar tu disco duro de Ps2 con el programa de l�nea de 
instrucciones Hdl_Dump. Puedes instalar un juego desde una Imagen-ISO o desde una unidad 
CD/DVD-ROM en tu disco duro de Ps2 formateado con Hdloader a trav�s de una conexi�n de red 
o con el disco duro conectado localmente (IDE/USB). Puedes ver una lista de los juegos que 
tienes instalados y editarlos. Tambi�n puedes borrar y copiar un juego en tu pc. 
Estas son las principales funciones. Para usar un disco duro en tu Ps2 necesitas un adaptador 
de red con un disco duro compatible. Tambi�n necesitas poder usar el programa HDLoader en tu 
Ps2 (necesitas el disco del Hdloader o instalarlo mediante modchip, swap, etc.).

HDL Dump Helper GUI est� programado en Java, de esa forma funciona en casi todos los SO
(eje. muchas distribuciones Linux, Windows) excepto MAC OS, porque no hay Hdl_Dump incluido
para MAC. 
Lo �nico que necesitas es la �ltima versi�n del Java Runtime Environment. 
El programa es muy explicativo gracias a su herramienta de consejos.

Para iniciar la GUI en Windows puedes usar el archivo .exe o simplemente haz doble clic en
el archivo .jar, el cual tambi�n funciona si el JRE est� bien instalado. 
Si en ambos casos no funciona ve a "Inicio" -> "Ejecutar" y escribe "cmd". Busca la carpeta 
que contiene la GUI usando la instrucci�n "cd". 
Ahora escribe "java -jar hdldh_gui.jar" y la GUI se ejecutar�.

Para iniciar la GUI en una distribuci�n de Linux puedes hacer doble clic en el 
bash-script ./launcher-linux si se quiere ejecutar a trav�s de "chmod +x <file>".
Si est�s en la consola tambi�n puedes escribir ./launcher-linux o "java -jar hdldh_gui.jar".

Puedes crear tambi�n un acceso directo en el escritorio si quieres. He incluido un icono 
que puedes usar para ello en la carpeta "/files" llamado "desk_icon.png". Coge el 
bash script y el icono a la hora de crear el acceso directo para el escritorio.
(Para usuarios de Linux)

El foro oficial del programa se encuentra aqu�:
"http://www.modcontrol.com/Board/thread.php?threadid=6494" (s�lo alem�n)

Puedes contactar conmigo para cualquier sugerencia:
(nomis-s@gmx.de)

Para m�s ayuda usa la "Ayuda" del programa.
Tambi�n puedes acceder a ella abriendo con un navegador el archivo "help_es.html" 
que se encuentra en la carpeta files/.


