#############################################################################
#############################################################################
#									                      #
#	  		            HDL DUMP HELPER GUI v2.			          #
#									                      #
#############################################################################
#############################################################################
# HDL DUMP HELPER GUI es una interf�cie gr�fica programada en Java,         #
# la cual ajuda a l'usuari a usar de forma senzilla el programari de l�nia  # 
# d'instruccions Hdl_Dump.                                                  #
#			                                                          #
#			     Escrit: 05/07			  	                #
#				 Autor: Simon Schaal                                #
#                Traducci�: El_Patas				                #
#############################################################################




Amb HDL Dump Helper GUI pots organitzar el teu disc dur de Ps2 amb el programari de l�nia
d'instruccions Hdl_Dump. Pots instal�lar un joc des d'una Imatge-ISO o des d'una unitat
CD/DVD-ROM en el teu disc dur de Ps2 formatejat amb Hdloader a trav�s d'una connexi� de xarxa
o amb el disc dur connectat localment (IDE/USB). Pots veure una llista dels jocs que
tens instal�lats i editar-los. Tamb� pots esborrar i copiar un joc en el teu pc.
Aquestes s�n les principals funcions. Per a usar un disc dur en la teva Ps2 necessites 
un adaptador de xarxa amb un disc dur compatible. Tamb� necessites poder usar el programa 
HDLoader en la teva Ps2 (necessites el disc del Hdloader o instal�lar-lo mitjan�ant 
modchip, swap, etc.). 

HDL Dump Helper GUI est� programat en Java, d'aquesta forma funciona en gaireb� tots els SO
(ex. moltes distribucions Linux, Windows) excepte MAC OS, perqu� no hi ha Hdl_Dump incl�s
per a MAC.
L'�nica cosa que necessites �s l'�ltima versi� del Java Runtime Environment.
El programari �s molt explicatiu gr�cies a la seva eina de consells.

Per a iniciar la GUI en Windows pots usar el fitxer .exe o simplement fes doble clic en
el fitxer .jar, el qual tamb� funciona si el JRE est� b� instal�lat.
Si en ambd�s casos no funciona v�s a "Inici" -> "Executar" i escriu "cmd". Busca la carpeta
que cont� la GUI usant la instrucci� "cd".
Ara escriu "java -jar hdldh_gui.jar" i la GUI s'executar�. 

Per a iniciar la GUI en una distribuci� de Linux pots fer doble clic en el 
bash-script ./launcher-linux si es vol executar a trav�s de "chmod +x <file>".
Si est�s en la consola tamb� pots escriure ./launcher-linux o "java -jar hdldh_gui.jar".

Pots crear tamb� un acc�s directe en l'escriptori si vols. He incl�s una icona
que pots usar per a aix� en la carpeta "/files" anomenat "desk_icon.png". Agafa
el bash script i la icona a l'hora de crear l'acc�s directe per a l'escriptori.
(Per a usuaris de Linux) 

El f�rum oficial del programari es troba aqu�:
"http://www.modcontrol.com/Board/thread.php?threadid=6494" (nom�s alemany)

Pots posarte en contacte amb mi per a qualsevol suggeriment:
(nomis-s@gmx.de)

Per a m�s ajuda usa la "Ajuda" del programari.
Tamb� pots accedir a ella obrint amb un navegador el fitxer "help_ca.html" 
que es troba en la carpeta files/.


