Credits
--------------------------------------------------------------------------------------------

The background image that serves as a menu was created by Gledson999.

The buttons, the warning icon, the texts in spanish with some color added,
the texts in other languages on request of other users, this pack
and the documentation was created by El_Patas.

Installation
--------------------------------------------------------------------------------------------

Take the three files "IGR_BG.TM2", "IGR_NO.TM2" and "IGR_YES.TM2" from the chosen 
language and copy them according to your device in:

Internal hard drive: hdd0:/__common /POPS
USB device: mass:/POPS

And this is all. Enjoy.

El_Patas