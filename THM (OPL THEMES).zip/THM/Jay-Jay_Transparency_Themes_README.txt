Recommended OPL Display Settings for the Transparency * Themes:

- Widescreen: ON

PAL users should download the PAL theme set.
NTSC users should download the NTSC theme set.

For instructions on how to use these themes, go to: 
http://www.ps2-home.com/forum/viewtopic.php?f=51&t=111