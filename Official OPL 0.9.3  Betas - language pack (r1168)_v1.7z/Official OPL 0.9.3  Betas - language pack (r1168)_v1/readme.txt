This is OPL 0.9.3+ Official Beta revisions language pack. 

These language files are to be used with OPL 0.9.3+ Official Beta revisions releases. 
You can download the betas from here : http://psx-scene.com/forums/f150/open-ps2-loader-official-beta-revisions-releases-156208/#post1208017
or here : https://akuhak.github.io/test_build/

*****

Thanks everyone who contributed/will contribute. Credits to original authors. Let's not forget all former OPL translators, as their translations are often used as a base for updates, so they should also be credited.

*****

Q/ HOW TO USE THESE LANGUAGE FILES ?

A/
1. Copy/paste the file named "lang_nameofyourlanguage.lng" and copy/paste it into mc?:/OPL folder ;
2. If your language uses some special glyphs, you will also need to use a custom font (provided in the archive). 
Copy/paste font_nameofyourlanguage.ttf into mc?:/OPL folder ;
3. In OPL, go to the main settings screen, then enter "Display settings" and set your language from there ;
4. Do not forget to save your Settings ;
5. Enjoy OPL in your language.

*

Q/ HOW TO USE CUSTOM FONT WITH OPL BUILT-IN ENGLISH ?

A/
You can not use a custom font with built-in English language. So, here is a trick :
1. Grab the file named "lang_EN-CustomFont.lng" (in "Language files and fonts\English (for custom font users)" folder ;
2. Rename your custom font as "font_EN-CustomFont.ttf" ;
3. Install these files like any external language ;
4. In OPL, go to the main settings screen, then enter "Display settings" and set "EN-CustomFont" from there.
5. Do not forget to save your Settings.
6. Enjoy OPL in english with a custom font.

*

Q/ MY LANGUAGE IS NOT LISTED ! AND/OR Q/ MY LANGUAGE IS ALREADY TRANSLATED BUT I THINK THE TRANSLATION SUCKS !

A/
Dude, that's not a question (oO) Use the english template provided in the archive and feel free to submit it here, either as text using [ CODE ][ /CODE ], either as a file. It will be included in the next version of the pack. You will be credited - of course.
If the translation already exists for your language but you don't like it, you can either contact the translator and work with him as a team or you can provide an alternate complete translation. Both translations will be included in the pack, so users from your country can make their own choice.

Anyone can come up with a new translation for OPL. 

If your language uses some special glyphs, you will also need to provide a font. When displayed on-screen, the characters should be clear and easy to read. The font must be compatible with the AFL v3.0 license.

- shaolinassassin for PSX-SCENE