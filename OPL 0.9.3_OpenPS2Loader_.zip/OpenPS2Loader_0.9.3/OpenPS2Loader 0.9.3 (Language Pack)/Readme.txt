===================================================================================================

This is OpenPS2Loader 0.9.3 language pack. 17 languages are available. 

These language files are to be used with OPL 0.9.3 stable releases ONLY (rev851, 
commit e505136). You can download 0.9.3 stable releases from here : 
https://bitbucket.org/ifcaro/open-ps2-loader/downloads

Language - author (status)

- Arabic - translated by LightWave
 (207/207 strings translated)
- Bulgarian - translated by wisi 
(207/207 strings translated)
- Czech - translated by jimmysmith
 (207/207 strings translated)
- French - translated by ShaolinAssassin (207/207 strings translated)
- German - translated by ps2guy
 (206/207 strings translated - missing : "Accurate Reads")
- Indonesian - translated by verislasher
 (207/207 string translated)
- Italian - translated by jauffreBlades (207/207 strings translated)
- Laotian - translated by blackbutterfly
 (204/207 strings translated - missing : "Enable write operations", "Synchronous Mode", "High module storage")
- Polish - translated by dragolice (207/207 strings translated)
- Portuguese-BR - translated by gledson999
 (207/207 strings translated)
- Portuguese - translated by danielb (206/207 strings translated - missing :"Accurate reads")
- Russian - translated by druchapucha
 & frodosumkin (206/207 strings translated - missing "Failed to start HDL Server")
- Spanish - translated by ElPatas
 (207/207 strings translated)
- Swedish - translated by Flaya
 (207/207 strings translated)
- Traditional Chinese - translated by kane159
 (207/207 strings translated)
- Turkish - translated by dante
 (201/207 strings translated - missing : "Enable write operations", "Accurate reads", "Synchronous Mode", "Auto start", "Value in second(s), 0 to disable auto start"). 

About the Filipino language : considering it has only 110/207 strings translated, it was 
not included in the language pack (but you can still found it on the repository). 

Credits to their authors.

Let's not forget all former OPL translators, as their translations are often used as a 
base for updates, so they should also be credited. 

===================================================================================================

HOW TO USE?

1. Copy/paste the file named "lang_nameofyourlanguage_0.9.3.lng" and copy/paste it 
   (using uLE) into mc?:/OPL/ folder.

2. If your language uses some special glyphs, you will also need to use a custom font 
   (provided in the archive). If there is no font in your language folder, you do not 
   need a special font.
   
The file "font_nameofyourlanguage_0.9.3.ttf can be placed (copy/paste using uLE) into: 

- mc?:/OPL/ folder

- mass:/ (root of your USB device)

- hdd0:/+OPL/ (if you load your font from HDD, start mode must be set on "AUTO")

3. In OPL, go to the main settings screen, then enter "Display settings" and set 
   your language from there.

4. Do not forget to save your Settings. 

5. Enjoy OPL in your language. ;)

===================================================================================================

HOW TO USE CUSTOM FONT WITH OPL BUILT-IN ENGLISH?

1. Grab the file named "lan_EN-CustomFont.lng" (in ""English for custom font users"" 
   folder)and copy/paste it (using uLE) into mc?:/OPL/ folder.

2. Rename your custom font "font_EN-CustomFont.ttf" and place it in either 
   mc?:/OPL/ folder, or mass:/ (root of your USB device), or hdd0:/+OPL/ 
   (HDD start mode must be set on "AUTO")

3. In OPL, go to the main settings screen, then enter "Display settings" and set 
   "EN-CustomFont" from there.

4. Do not forget to save your Settings. 

5. Enjoy OPL in english with a custom font. ;)

===================================================================================================

CHANGELOG: 

- 11/04/2015: v2.0 release - changes : 
 - Credits updated (Bulgarian, Italian & Russian languages).
 - Lang files & fonts renamed to _0.9.3 & Lang files have now a new line 2 ("# For 
   Open PS2 Loader 0.9.3 stable release (rev851, commit e505136)") to avoid confusion 
   with development builds.
 - Fonts for Russian, Bulgarian & Turkish now included in the pack.
 - Fonts for Czech, French, German, Italian, Portuguese & Portuguese-BR updated. 
 - Recommendation to TChinese users in the language folder added.
 - Blank lines (translation not provided by translator) fulfilled  with english, as the 
   option "Any missing lines will be substituted with the English defaults from lang.c" 
   is not working in the hint footer :'(
 - Fix on Bulgarian language (some english words remaining deleted).
 - Russian language updated.
 - "Map" of all languages in a spreadsheet added in the pack so now its possible to see 
   their status.
 - Lot of minor fixed i can't remember...

 -10/25/2015: initial release v1.0

===================================================================================================

MY LANGUAGE IS NOT LISTED ! 

Use the template below. Feel free to submit it @http://psx-scene.com/forums/official-open-ps2-loader-forum/

===================================================================================================

TEMPLATE for Open PS2 Loader - 0.9.3 

- https://bitbucket.org/ifcaro/open-ps2-loader/downloads

#####################################################################################
# This file is a template for translators. This file's encoding must be UTF8.                                                                                   #
#                                                                                                                                                                                                 #
# Translate every line, keeping the same order. Don't add empty lines.                                                                                      #
# Any missing lines will be substituted with the English defaults from lang.c.                                                                                 #
#                                                                                                                                                                                                 #
# Important: if your language require some custom glyphs, you should provide a corresponding                                               #
# TTF/OTF font file too. By default, OPL only comes with the "basic Latin" font built-in.                                                                #
#                                                                                                                                                                                                 #
# Once the translation is complete, you can submit it to the development team.                                                                            #
#                                                                                                                                                                                                 #
# To use your custom language with OPL, simply copy your file into your mc?:/OPL folder.                                                       #
# (File must start with the "lang_" prefix and have the ".lng" extension)                                                                                       #
#                                                                                                                                                                                                 #
# Finally, don't put too many comments in your file, it will waste space and increases loading                                                     #
# time. One single comment line on top (e.g. "name <yourmail@address.com>") should be enough.                                         #
#                                                                                                                                                                                                 #
# Thanks for your work.                                                                                                                                                              #
#                                                                                                                                                                                                 #
#####################################################################################
#
# Put here the English name of your language (will be displayed in the OPL Settings menu), in standard latin characters.
English
Open PS2 Loader %s
Save changes
Back
Network config
Advanced options
<no values>
Settings saved...
Error writing settings!
Exit
Settings
Menu
USB Games
HDD Games
ETH Games
Apps
Theme
Language
The system will be powered off.
Exit OPL?
Cancel updating?
%d: HardDisk Drive not detected
%d: HardDisk Drive not formatted
%d: Network startup error
%d: No network adaptor detected
%d: Cannot connect to SMB server
%d: Cannot log into SMB server
%d: Cannot open SMB share
%d: Cannot list SMB shares
%d: Cannot list games
%d: DHCP server unavailable
%d: No network connection
On
Off
OK
Select
Cancel
Circle
Cross
Games List
Game settings
Remove all settings
Removed all keys for the game
Scrolling
Slow
Medium
Fast
Default menu
Load from disc
Please wait
Error while loading the Game ID
Automatic sorting
Error loading the language file
Disable Debug Colors
No controller detected, waiting...
Enable Cover Art
Wide screen
Power off
Loading config
Saving config
Start device
Refresh
USB device start mode
HDD device start mode
ETH device start mode
Applications start mode
Auto
Manual
Start HDL Server
HDL Server Starting...
HDL Server Running...
Failed to start HDL Server.
HDL Server Unloading...
IGR path
Background color
Text color
- PS2 -
- SMB Server -
IP address type
Static
DHCP
IP address
Address
Mask
Gateway
DNS Server
Port
Share
User
Password
<not set>
Address type
IP
NetBIOS
Accept
Item will be permanently deleted, continue?
Rename
Delete
Run
Display settings
Enable write operations
Check USB game fragmentation
Remember last played game
Select button
Error, the game is fragmented
Error, could not run the item
Test
Leave empty for GUEST auth.
Accurate Reads
Synchronous Mode
Unhook Syscalls
0 PSS mode
Emulate DVD-DL
Disable IGR
High module storage
Hide DEV9 module
Changing the size will reformat the VMC
Create
Start
Modify
Abort
Reset
Use generic
Configure VMC
Name
Size
Status
Progress
VMC file exist
Invalid VMC file, size is incorrect
VMC file need to be created
Error with VMC %s, continue with physical MC (slot %d) ?
Automatic refresh
About
Coders
Quality Assurance
USB prefix path
Leave empty to exit to Browser
Value in minute(s), 0 to disable spin down
Automatic HDD spin down
Video mode
Dialog color
Selected color
Display info page
Info
Custom ELF
Color selection
Reconnect
Leave empty to list shares
ETH prefix path
Backspace
Space
Enter
Mode
VMC Slot 1
VMC Slot 2
Game ID
DMA Mode
V-Sync
Mode 1
Mode 2
Mode 3
Mode 4
Mode 5
Mode 6
Mode 7
Mode 8
Configure GSM
Ethernet link mode
100Mbit full-duplex
100Mbit half-duplex
10Mbit full-duplex
10Mbit half-duplex
GSM Settings
Enable GSM
Toggles GSM ON or OFF
VMODE
Forced Custom Display Mode
H-POS
Horizontal Adjustment
V-POS
Vertical Adjustment
FMV Skip
Skips Full Motion Videos
Cheat Settings
Enable PS2RD Cheat Engine
Lets PS2RD Cheat Engine patch your games
PS2RD Cheat Engine Mode
Auto-select or Select game cheats
Auto-select cheats
Select game cheats
Error: failed to load Cheat File
No cheats found
Download defaults
Network update
Re-download existing records?
Update failed.
Failed to connect to update server.
Update completed.
Update cancelled.
Download settings from the network?
Customized Settings
Downloaded Defaults
Auto start in %i s...
Auto start
Value in second(s), 0 to disable auto start
# [end of the template]


